Requirements:
- Python 3.6.8
- PyTorch 1.0.1

To produce the experiment results with our method:  
1. in Table 2:
    ```
        python linear_model.py
    ```

2. in Table 3:
    ```
        python nn_Drive.py
    ```

3. in Table 4:
    ```
        python nn_MNIST.py
    ```
4. in supplementary material:
    ```
        python linear_model_0.py
    ```

    ```
        python nn_Avila.py
    ```
